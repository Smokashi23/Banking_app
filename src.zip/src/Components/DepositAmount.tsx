import React, { useState } from 'react';
import { useAppDispatch } from '../hooks';
import { depositAmount } from '../redux/accountSlice'

const DepositAmount: React.FC = () => {
  const dispatch = useAppDispatch();
  const [accNo, setAccNo] = useState<number>(0);
  const [amount, setAmount] = useState<number>(0);

  const handleAccNoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAccNo(parseInt(e.target.value));
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(parseFloat(e.target.value));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(depositAmount({ accNo, amount }));
  };

  return (
    <div>
      <h2>Deposit Amount</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Account Number"
          value={accNo}
          onChange={handleAccNoChange}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={handleAmountChange}
        />
        <button type="submit">Deposit</button>
      </form>
    </div>
  );
};

export default DepositAmount;