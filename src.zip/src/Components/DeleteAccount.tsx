import React, { useState } from 'react';
import { useAppDispatch } from '../hooks';
import { deleteAccount } from '../redux/accountSlice'

const DeleteAccount: React.FC = () => {
  const dispatch = useAppDispatch();
  const [accNo, setAccNo] = useState<number>(0);

  const handleAccNoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAccNo(parseInt(e.target.value));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(deleteAccount(accNo));
  };

  return (
    <div>
      <h2>Delete Account</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Account Number"
          value={accNo}
          onChange={handleAccNoChange}
        />
        <button type="submit">Delete Account</button>
      </form>
    </div>
  );
};

export default DeleteAccount;