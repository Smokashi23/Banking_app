import React, { useState } from 'react';
import axios from 'axios';
import { useAppDispatch, useAppSelector } from '../hooks';
import { createAccount } from '../redux/accountSlice';
import { Account } from '../interfaces';
import { RootState } from '../redux/store';

const CreateAccount: React.FC = () => {
  const dispatch = useAppDispatch();
  const { isLoading, error } = useAppSelector((state: RootState) => state.account);

  const [formData, setFormData] = useState<Account>({
    branch_id: 0,
    acc_type: '',
    balance: 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
    
      const response = await axios.post('http://localhost:1925/account/create', formData);
     
      dispatch(createAccount(formData));
   
      console.log('Account created successfully:', response.data);
   
      setFormData({
        branch_id: 0,
        acc_type: '',
        balance: 0,
      });
    } catch (error) {
      // Handle error
      console.error('Error creating account:', error.message);
    }
  };

  return (
    <div>
      <h2>Create Account</h2>
      {isLoading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          name="branch_id"
          placeholder="Branch ID"
          value={formData.branch_id}
          onChange={handleChange}
        />
        <input
          type="text"
          name="acc_type"
          placeholder="Account Type"
          value={formData.acc_type}
          onChange={handleChange}
        />
        <input
          type="number"
          name="balance"
          placeholder="Initial Balance"
          value={formData.balance}
          onChange={handleChange}
        />
        <button type="submit">Create Account</button>
      </form>
    </div>
  );
};

export default CreateAccount;
